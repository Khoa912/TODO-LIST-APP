import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Switch,
  Picker,
} from 'react-native';

const TodoApp = () => {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [filterDone, setFilterDone] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [searchText, setSearchText] = useState('');

  const addTask = () => {
    if (newTask.trim() !== '') {
      setTasks([
        ...tasks,
        {
          id: Date.now(),
          text: newTask,
          done: false,
          timestamp: new Date(),
          type: filterType,
        },
      ]);
      setNewTask('');
    }
  };

  const toggleDone = (id) => {
    const updatedTasks = tasks.map((task) =>
      task.id === id ? { ...task, done: !task.done, timestamp: new Date() } : task
    );
    setTasks(updatedTasks);
  };

  const deleteTask = (id) => {
    const updatedTasks = tasks.filter((task) => task.id !== id);
    setTasks(updatedTasks);
  };

  const renderTask = ({ item }) => {
    if (
      ((filterDone === 'all' || (filterDone === 'done' && item.done) || (filterDone === 'notDone' && !item.done)) &&
      (filterType === 'all' || item.type === filterType)) &&
      (item.text.toLowerCase().includes(searchText.toLowerCase()) || searchText === '')
    ) {
      return (
        <View style={[styles.taskContainer, item.done && styles.doneTask]}>
          <Text style={[styles.taskText, item.done && styles.doneTaskText]}>
            {item.text}
          </Text>
          <Text style={styles.typeText}>{item.type}</Text>
          <Switch value={item.done} onValueChange={() => toggleDone(item.id)} />
          <TouchableOpacity
            style={styles.deleteButton}
            onPress={() => deleteTask(item.id)}
          >
            <Text style={styles.deleteButtonText}>DELETE</Text>
          </TouchableOpacity>
          <Text style={styles.timestamp}>{formatTimestamp(item.timestamp)}</Text>
        </View>
      );
    } else {
      return null;
    }
  };

  const formatTimestamp = (timestamp) => {
    const options = { year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric' };
    return new Date(timestamp).toLocaleDateString(undefined, options);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>TODO LIST APP</Text>
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Add a new task"
          value={newTask}
          onChangeText={(text) => setNewTask(text)}
        />
        <Picker
          style={styles.picker}
          selectedValue={filterType}
          onValueChange={(itemValue) => setFilterType(itemValue)}
        >
          <Picker.Item label="All Types" value="all" />
          <Picker.Item label="Type 1" value="type1" />
          <Picker.Item label="Type 2" value="type2" />
          {/* Add more types as needed */}
        </Picker>
        
        <TouchableOpacity style={styles.addButton} onPress={addTask}>
          <Text style={styles.addButtonText}>+</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.filterContainer}>
        <Text>Show:</Text>
        <Picker
          style={styles.picker}
          selectedValue={filterDone}
          onValueChange={(itemValue) => setFilterDone(itemValue)}
        >
          <Picker.Item label="All" value="all" />
          <Picker.Item label="Done" value="done" />
          <Picker.Item label="Not Done" value="notDone" />
        </Picker>
      </View>
      <TextInput
        style={styles.searchInput}
        placeholder="Search..."
        value={searchText}
        onChangeText={(text) => setSearchText(text)}
      />
      <FlatList
        data={tasks}
        renderItem={renderTask}
        keyExtractor={(item) => item.id.toString()}
        style={styles.taskList}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    textAlign: 'center',
    backgroundColor: '#333',
    paddingBottom: 28,
    color: 'white',
    padding: 20,
  },
  inputContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  input: {
    flex: 2,
    height: 35,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 8,
    marginBottom: 8,
  },
  picker: {
    flex: 1,
    height: 35,
    marginBottom: 8,
  },
  addButton: {
    flex: 1,
    backgroundColor: 'brown',
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    paddingBottom: 5,
    marginLeft: 8,
    borderwidth: 1,
    height:30,
    marginBottom:8,
   
  },
  addButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize:20,
    
  },
 taskList: {
    marginTop: 10,
    backgroundColor: '#ecf0f1',
    borderRadius: 8,
  },
  taskContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 4,
    padding: 12,
    marginBottom: 8,
  },
  taskText: {},
  doneTask: {
    backgroundColor: '#dfe6e9',
  },
  
  doneTaskText: {
    textDecorationLine: 'underline',
    color: 'red',
  },
   typeText: {
    marginLeft: 10,
    color: 'blue',
  },
  deleteButton: {
    backgroundColor: 'red',
    borderRadius: 4,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 8,
    marginLeft: 8,
  },
  deleteButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  filterContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  searchInput: {
    height: 35,
    borderColor: 'gray',
    borderWidth: 1,
    paddingHorizontal: 8,
    marginBottom: 8,
  },
  timestamp: {
    marginLeft: 10,
  },
});

export default TodoApp;
